import React from 'react'
import './footer.css'

export const FooterLogin = () => {
  return (
   <div className='footer'>footer</div>
  )
}
