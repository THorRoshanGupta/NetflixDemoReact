import React from 'react'
import './Netflixstream.css'
import Navbar1 from './Navbar1'
import '../Nav.css'
import Preview from './Preview'
import Selector from './Selector'


export default function Netflixstream() {
  return (
    
    
    <div className='home1'>
      <Navbar1></Navbar1>
      <Preview></Preview>
      <Selector></Selector>
    </div>
  
  )
}
