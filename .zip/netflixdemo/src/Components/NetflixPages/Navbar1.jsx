import React from 'react'

import './Navbar1.css' 
export default function Navbar1() {
  return (
   
    <div className='nav logohome'>
        <div className="logo "  >NETFLIX</div>
        <div className='drops'> Home</div>
        <div className='drops'> Tv Shows</div>
        <div className='drops'> Movies</div>
        <div className='drops'> News & Popular</div>
        
       
       
    </div>
    
  )
}
