import React from 'react'

import './Preview.css'
import MovieContent from './MovieContent'

export default function Preview() {
  console.log("err","i mean ")
  return (
    <div className='preview' >
      <MovieContent></MovieContent>
      
        
    </div>
  )
}
