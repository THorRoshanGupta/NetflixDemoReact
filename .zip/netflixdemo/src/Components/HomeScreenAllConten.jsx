import React from 'react'
import Home from './Home'
import Content from './Content'
import Promotion from './Promotion'
import Promotion2 from './Promotion2'


export default function HomeScreenAllConten() {
  return (
     <div  >
      <Home></Home>
        
         <Content></Content>
         <Promotion></Promotion>
         <Promotion2></Promotion2>
       
    </div>
  )
}
